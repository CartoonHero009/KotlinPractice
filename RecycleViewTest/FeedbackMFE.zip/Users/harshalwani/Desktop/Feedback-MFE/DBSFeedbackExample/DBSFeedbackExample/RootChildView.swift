//
//  RootChildView.swift
//  DBSFeedbackExample
//
//  Created by Mandar MOHAN KADAM on 14/3/19.
//  Copyright © 2019 DBS. All rights reserved.
//

import Foundation
import UIKit
import DBSCore
import DBSFeedback
protocol CallbackDelegate {
    func loadRatingView()
}
public class RootChildView: UIView {
    fileprivate let root = UIView()
    var delegate: CallbackDelegate?
    public init() {
        super.init(frame: .zero)
        configure()
        layout()
    }
    func configure() {
        backgroundColor = Color.primary.value
    }
    func layout() {
        let button = DBSButton(style: Stylesheet.button.primary)
        root.flex.direction(.column).alignSelf(.center).define { (flex) in
                flex.addItem(button).top(100).marginRight(100).height(100).width(100)
            }
        addSubview(root)
        
        button.addTarget(self, action: #selector(surveyTapped), for: .touchUpInside)
        button.backgroundColor = .yellow
        button.titleLabel?.text = "Feedback"
        button.titleLabel?.textColor = .black
    }
    override public func layoutSubviews() {
        super.layoutSubviews()
        root.pin.all(pin.safeArea)
        root.pin.top().horizontally()
        root.flex.layout(mode: .adjustHeight)
        root.frame = self.frame
    }
    @objc func surveyTapped() {
        delegate?.loadRatingView()
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
