//
//  RootController.swift
//  DBSFeedbackExample
//
//  Created by Mandar MOHAN KADAM on 12/3/19.
//  Copyright © 2019 DBS. All rights reserved.
//

import Foundation
import UIKit
import DBSCore
import DBSFeedback

class RootController: UIViewController {
    var loadingView = DBSSurveyLoadingView()
    var controller: DBSFeedbackViewController?
    fileprivate var mainView: RootChildView {
        return self.view as! RootChildView
    }
    override func loadView() {
        LANG_DEFAULT_DISPLAY = "zh"
        let view = RootChildView()
        view.delegate = self
        self.view = view
    }
    override func viewWillAppear(_ animated: Bool) {
        loadRatingView()
    }
    func showFonts() {
        for family in UIFont.familyNames.sorted() {
            let names = UIFont.fontNames(forFamilyName: family)
            print("Family: \(family) Font names: \(names)")
        }
    }    
}

extension RootController: CallbackDelegate {
    func loadRatingView() {
        let input = FeedbackInputData(title: LocalizableStrings.headerTitle.localized,
                                      reasons: [LocalizableStrings.lookAndFeel.localized,
                                                LocalizableStrings.easeOfFindingServices.localized,
                                                LocalizableStrings.easeOfuse.localized,
                                                LocalizableStrings.technicalIssues.localized,
                                                LocalizableStrings.languageClarity.localized,
                                                LocalizableStrings.others.localized],
                                      language: "zh")
        
        self.controller = DBSFeedbackViewController(feedbackInput: input)
        controller?.handler = self
        self.navigationController?.pushViewController(controller!, animated: true)
    }
}
extension RootController: FeedbackHandler {
    func dismissFeedback() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    public func submitFeedback(userFeedback: FeedbackOutpuData) {
        print("Feedback or output: \(userFeedback)")
        if let app = UIApplication.shared.delegate as? AppDelegate, let window = app.window {
            loadingView.frame = UIScreen.main.bounds
            loadingView.backgroundColor = UIColor.black.withAlphaComponent(0.7)
            window.addSubview(loadingView)
            loadingView.center = window.center
        }
        let delayInSeconds = 1.5
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            self.loadingView.removeFromSuperview()
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
}
